import java.util.ArrayList;

public class Tesouro extends Unidade{

    public Tesouro(){

    }

    @Override
    public ArrayList<Posicao> movimentos(Campo campo) {
        return null;
    }

    @Override
    public ArrayList<Posicao> defesa(Campo campo) {
        return null;
    }

    @Override
    protected Posicao getPosicao() {
        return null;
    }
}
