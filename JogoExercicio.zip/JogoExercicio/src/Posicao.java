public class Posicao {

    private Unidade unidade;

    public Unidade getUnidade() {
        return unidade;
    }

    public void setUnidade(Unidade unidade) {
        this.unidade = unidade;
    }

    public void moverPeca(Campo campo, Posicao posicao){

    }



}
