import java.util.ArrayList;

public class Infantaria extends Unidade{

    int quantidadeCasas;
    int posicaoMover;

    public Infantaria( ){
        quantidadeCasas= this.quantidadeCasas;
        posicaoMover = this.posicaoMover;
    }

    public Infantaria(int quantidadeCasas, int posicaoMover) {
        super();
    }

    public ArrayList<Posicao> movimentos(Campo campo) {
        ArrayList<Posicao> movimentos = new ArrayList<>();
        Posicao posicaoAtual = this.getPosicao();
        int posicaoJogo = campo.getPosicao().indexOf(posicaoAtual);
        ArrayList<Posicao> posicoesJogo = campo.getPosicao();

        if ((posicaoMover == 12 && quantidadeCasas == 1) ||
                (posicaoMover == 13 && quantidadeCasas == 1) ||
                (posicaoMover == 16 && quantidadeCasas == 1) ||
                (posicaoMover == 17 && quantidadeCasas == 1) ||
                (posicaoMover == 18 && quantidadeCasas == 1) ||
                (posicaoMover == 19 && quantidadeCasas == 1) ||
                (posicaoMover == 22 && quantidadeCasas == 1) ||
                (posicaoMover == 23 && quantidadeCasas == 1) ||
                (posicaoMover == 60 && quantidadeCasas == 1) ||
                (posicaoMover == 61 && quantidadeCasas == 1) ||
                (posicaoMover == 64 && quantidadeCasas == 1) ||
                (posicaoMover == 65 && quantidadeCasas == 1) ||
                (posicaoMover == 66 && quantidadeCasas == 1) ||
                (posicaoMover == 67 && quantidadeCasas == 1) ||
                (posicaoMover == 70 && quantidadeCasas == 1) ||
                (posicaoMover == 71 && quantidadeCasas == 1)) {

            if (identificaPeca(posicaoAtual)) {
                for (int i = 1; i <= quantidadeCasas; i++) {
                    if (posicaoJogo + i < posicoesJogo.size()) {
                        movimentos.add(posicoesJogo.get(posicaoJogo + i));
                    }
                }
            } else {
                return null;
            }
        }

        return movimentos;
    }

        private boolean identificaPeca(Posicao posicao) {
            Unidade unidade = posicao.getUnidade();
            return unidade instanceof Infantaria;
        }




        @Override
    public ArrayList<Posicao> defesa(Campo campo) {
        return null;
    }

    @Override
    public String toString() {
        return "Infantaria{} ";
    }

    @Override
    protected Posicao getPosicao() {
        return null;
    }
}
