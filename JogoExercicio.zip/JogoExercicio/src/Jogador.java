public class Jogador {
}
