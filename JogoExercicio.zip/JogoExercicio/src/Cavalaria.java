import java.util.ArrayList;

public class Cavalaria extends Unidade{
    @Override
    public ArrayList<Posicao> movimentos(Campo campo) {
        ArrayList<Posicao> movimentos = new ArrayList<>();
        for(Posicao posicao: campo.getPosicao()){
            int indice = campo.getPosicao().indexOf(posicao);
        }
        return movimentos;
    }

    @Override
    public ArrayList<Posicao> defesa(Campo campo) {
        return null;
    }

    @Override
    public String toString() {
        return "Cavalaria{} " ;
    }

    @Override
    protected Posicao getPosicao() {
        return null;
    }
}
