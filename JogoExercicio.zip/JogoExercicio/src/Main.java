import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Campo campo = new Campo();
        campo.imprimirJogo();

        System.out.println("Qual posição deseja mover? (Digite o índice da peça)");
        int posicaoMover = sc.nextInt();

        System.out.println("Quantas casas deseja mover?");
        int quantidadeCasas = sc.nextInt();

        Infantaria infantaria = new Infantaria(quantidadeCasas, posicaoMover);
        ArrayList<Posicao> movimentos = infantaria.movimentos(campo);

        // Verificar se o movimento é válido
        if (movimentos != null && !movimentos.isEmpty()) {
            // Realizar o movimento
            Posicao novaPosicao = movimentos.get(movimentos.size() - 1);
            Posicao posicaoAnterior = campo.getMovimento(posicaoMover);

            if (posicaoAnterior != null) {
                posicaoAnterior.setUnidade(null);
                novaPosicao.setUnidade(infantaria);
                campo.imprimirJogo();
            } else {
                System.out.println("Posição inválida! Movimento não realizado.");
            }
        } else {
            System.out.println("Movimento inválido!");
        }
    }

}
